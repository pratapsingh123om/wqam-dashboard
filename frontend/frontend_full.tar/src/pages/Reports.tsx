export default function Reports() { return <div class='glass p-6'>Reports Page (coming soon)</div>; }
