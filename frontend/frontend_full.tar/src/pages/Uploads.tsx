export default function Uploads() { return <div class='glass p-6'>Uploads Page (coming soon)</div>; }
