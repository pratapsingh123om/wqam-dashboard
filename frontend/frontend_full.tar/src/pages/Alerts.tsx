export default function Alerts() { return <div class='glass p-6'>Alerts Page (coming soon)</div>; }
